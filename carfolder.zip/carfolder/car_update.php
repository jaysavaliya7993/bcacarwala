<?php
session_start();
$email = $_SESSION['u_email'];
?>

<html>

    <head>
        <meta charset="UTF-8">
        <title> Upload Car Page</title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

        <link rel="stylesheet" href="../cssfolder/carupload.css">
        <!--<link rel="stylesheet" href="../cssfolder/new.scss">-->
    </head>
    <?php $id = $_GET['u_id'] ?>
    <body>
        <nav class="navbar sticky-top navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="../carfolder/Homepage.php?u_id=<?php echo $id; ?>">BCACARWALA</a>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Home</a>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">New Car</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#">Search new Car</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Latest Car</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Upcoming Car</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Electric Car</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Suggest Me A Car</a></li>
                            </ul>
                        </li>
                        <?php $id = $_GET['u_id'] ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">Used Car</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li class="dropdown-submenu">
                                <li><a class="dropdown-item" href="#">Sell Car In Your City</a>
                                    <ul class="submenu dropdown-menu dropdown-menu-left">
                                        <li><a class="dropdown-item" href="#">Mota Varachha</a></li>
                                        <li><a class="dropdown-item" href="#">Hirabag</a></li>
                                        <li><a class="dropdown-item" href="#">Jakat Naka</a></li>
                                        <li><a class="dropdown-item" href="#">Sachin</a></li>
                                        <li><a class="dropdown-item" href="#">Udhana</a></li>
                                        <li><a class="dropdown-item" href="#">Vesu</a></li>
                                        <li><a class="dropdown-item" href="#">Dumas</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="carupload.php?u_id=<?php echo $id; ?>">Sell Used Car</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="Viewcar.php?u_id=<?php echo $id; ?>">Bcw Used car</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">My Listing</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">Sell Car</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#">Sell Car In Your City</a>
                                    <ul class="submenu dropdown-menu dropdown-menu-left">
                                        <li><a class="dropdown-item" href="#">Mota Varachha</a></li>
                                        <li><a class="dropdown-item" href="#">Hirabag</a></li>
                                        <li><a class="dropdown-item" href="#">Jakat Naka</a></li>
                                        <li><a class="dropdown-item" href="#">Sachin</a></li>
                                        <li><a class="dropdown-item" href="#">Udhana</a></li>
                                        <li><a class="dropdown-item" href="#">Vesu</a></li>
                                        <li><a class="dropdown-item" href="#">Dumas</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Sell Car By Brand</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">How it Works?</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">FAQS?</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">Popular Brand</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li>
                                    <a class="dropdown-item" href="#">Tata</a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Maruti Suzuki</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Huyndai</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Mahindra</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Kia</a></li>
                            </ul>
                        </li>
                    </ul>

                    <?php $id = $_GET['u_id'] ?>
                    <form class="form">
                        <nav class="navvv">
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav  mb-2 mb-lg-0">
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                           data-bs-toggle="dropdown" aria-expanded="false">
                                               <?php
                                               // USERNAME CODE<!--session code-->
                                               $conn = new mysqli('localhost', 'root', '', 'bcw');
                                               if ($conn->connect_error) {
                                                   die("Connection Faield" . $conn->connect_error);
                                               }
                                               $sql = "SELECT * FROM tbl_m_user WHERE u_email = '$email'";
                                               $result = $conn->query($sql);
                                               if ($result->num_rows > 0) {
                                                   while ($row = $result->fetch_assoc()) {
                                                       echo '<style="text-align: left"><b>' . $row['u_username'] . ' ' . '</b></a>';
                                                       $id = $row['u_id'];
                                                   }
                                               }
                                               ?>
                                        </a>

                                        <ul class="dropdown-menu dropdown-menu-end"
                                            aria-labelledby="navbarDropdownMenuAvatar">
                                            <li>
                                                <a class="dropdown-item">
                                                    <?php
                                                    // USERNAME CODE<!--session code-->
                                                    $conn = new mysqli('localhost', 'root', '', 'bcw');
                                                    if ($conn->connect_error) {
                                                        die("Connection Faield" . $conn->connect_error);
                                                    }
                                                    $sql = "SELECT * FROM tbl_m_user WHERE u_email = '$email'";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            echo '<style="text-align: left"><b>' . $row['role'] . ' ' . '</b></a>';
                                                            $id = $row['u_id'];
                                                        }
                                                    }
                                                    ?>
                                                </a>
                                            </li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="../userfolder/viewprofile.php?u_id=<?php echo $id; ?>">View Profile</a>
                                            </li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="../userfolder/managecar.php?u_id=<?php echo $id; ?>">Mange Car Details</a>
                                            </li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="../userfolder/forgot.php">Change Password </a>
                                            </li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="../userfolder/M_User.php">Logout</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </form>
                </div>
            </div>
        </nav>

    <body>

        <div>
            <h2>
                <b>Upload your car details</b>
            </h2>
        </div>

        <div>
            <div class="right"> 
                <!--                <form method="post" action="cardatastore.php" enctype="multipart/form-data">-->
                <form action="action" method="POST" enctype="multipart/form-data">
                    <div class="input-group">
                                        <!--<i class='bx bxs-user'></i>-->
                        <input type="text" class="form-control form-control-s" name="c_no" placeholder="Enter Car Number">
                    </div>

                    <div class="input-group">
                        <!--<i class='bx bxs-user'></i>-->
                        <input type="text" name="c_vin_no" placeholder="Enter Vhehical Identification Number">
                    </div>

<!--                    <script>
                        function validateVIN() {
                            const vinInput = document.getElementById("vinInput").value.toUpperCase();
                            const vinPattern = /^[A-HJ-NPR-Z0-9]{17}$/; // Basic VIN format check

                            if (vinPattern.test(vinInput)) {
                                document.getElementById("validationResult").textContent = "VIN is valid.";
                            } else {
                                document.getElementById("validationResult").textContent = "VIN is invalid.";
                            }
                        }
                    </script>-->

                    <div class="input-group">
                        <!--<i class='bx bxs-user'></i>-->
                        <input type="text" name="c_company_name" placeholder="Enter Car Company Name">
                    </div>

                    <div class="input-group">
                        <!--<i class='bx bxs-user'></i>-->
                        <input type="text" name="c_model" placeholder="Enter Car Model">
                    </div>

                    <div class="input-group">
                        <!--<i class='bx bxs-user'></i>-->
                        <input type="text" name="c_version" placeholder="Enter Car Version">
                    </div>

                    <div class="input-group">
                        <!--<i class='bx bxs-user'></i>-->
                        <select for="year" class="form-control form-control-s" name="c_make_year">
                            <option>Choose Make year</option>
                            <option value="2009">2009</option>
                            <option value="2010">2010</option>
                            <option value="2011">2011</option>
                            <option value="2012">2012</option>
                            <option value="2013">2013</option>
                            <option value="2014">2014</option>
                            <option value="2015">2015</option>
                            <option value="2016">2016</option>
                            <option value="2017">2017</option>
                            <option value="2018">2018</option>
                            <option value="2019">2019</option>
                            <option value="2020">2020</option>
                            <option value="2021">2021</option>
                            <option value="2022">2022</option>
                            <option value="2023">2023</option>
                            <option value="2024">2024</option>
                        </select>
                    </div>

                    <div class="input-group">
                        <!--<i class='bx bxs-user'></i>-->
                        <select for="month" class="form-control form-control-s" name="c_make_month">
                            <option>Choose Make Month</option>
                            <option value="January">January</option>
                            <option value="February">February</option>
                            <option value="March">March</option>
                            <option value="April">April</option>
                            <option value="May">May</option>
                            <option value="June">June</option>
                            <option value="July">July</option>
                            <option value="August">August</option>
                            <option value="September">September</option>
                            <option value="October">October</option>
                            <option value="October">November</option>
                            <option value="December">December</option>
                        </select>
                    </div>

                    <div class="input-group">
                        <!--<i class='bx bxs-user'></i>-->
                        <input type="text" id="kilometer" name="kilometer" placeholder="Enter Car kilometer">
                    </div>

                    <div class="input-group">
                        <!--<i class='bx bxs-user'></i>-->
                        <input type="date" name="c_upload_date" placeholder="Enter Car upload date">
                    </div>

            </div>

            <div class="left">

                <div class="input-group">
                    <!--<i class='bx bxs-user'></i>-->
                    <select for="seating" class="form-control form-control-s" name="c_seating_cap">
                        <option> Car Seating Capacity</option>
                        <option value="2">2</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                    </select>
                </div>

                <div class="input-group">
                    <!--<i class='bx bxs-user'></i>-->
                    <select for="Fuel" class="form-control form-control-s" name="c_fule_type">
                        <option>Choose Fuel Type</option>
                        <option value="Diseal">Diseal</option>
                        <option value="Petrol">Petrol</option>
                        <option value="Cng">Cng</option>
                        <option value="Ev">Ev</option>
                    </select>
                </div>

                <div class="input-group">
                    <!--<i class='bx bxs-user'></i>-->
                    <select class="form-control form-control-s" name="c_transmis_type">
                        <option>Choose Trasmission Type</option>
                        <option value="Auto">Auto</option>
                        <option value="Manual">Manual </option>
                    </select>
                </div>

                <div class="input-group">
                    <!--<i class='bx bxs-user'></i>-->
                    <select class="form-control form-control-s" name="c_insurance_type">
                        <option>Choose Insurance Type</option>
                        <option value="Include">Include</option>
                        <option value="Third Party">Third Party</option>
                    </select>
                </div>

                <div class="input-group">
                    <!--<i class='bx bxs-user'></i>-->
                    <select for="Owner" class="form-control form-control-s" name="c_no_of_owner">
                        <option>Select Car Owner</option>
                        <option value="First">First</option>
                        <option value="Second">Second</option>
                        <option value="Third">Third</option>
                        <option value="Four or more">Four or more</option>
                    </select>
                </div>

                <div class="input-group">
                    <!--<i class='bx bxs-user'></i>-->
                    <select for="color" class="form-control form-control-s" name="c_color">
                        <option>Choose Car Color</option>
                        <option value="Aqua">Aqua</option>
                        <option value="Black">Black</option>
                        <option value="Blue">Blue</option>
                        <option value="CadetBlue">CadetBlue</option>
                        <option value="Cyan">Cyan</option>
                        <option value="DarkBlue">DarkBlue</option>
                        <option value="DarkCyan">DarkCyan</option>
                        <option value="DarkGray">DarkGray</option>
                        <option value="DarkMagenta">DarkMagenta</option>
                        <option value="DarkOrange">DarkOrange</option>
                        <option value="DarkRed">DarkRed</option>
                        <option value="Indigo">Indigo</option>
                        <option value="GreenYellow">GreenYellow</option>
                        <option value="Green">Green</option>
                        <option value="Red">Red</option>
                        <option value="Yellow">Yellow</option>
                        <option value="YellowGreen">YellowGreen</option>
                        <option value="White">White</option>
                        <option value="Silver">Silver</option>
                        <option value="MidnightBlue">MidnightBlue</option>
                        <option value="Maroon">Maroon</option>
                    </select>
                </div>

                <div class="input-group">
                    <!--<i class='bx bxs-user'></i>-->
                    <input type="File" class="form-control form-control-s" name="pic" placeholder="Choose Car Image">
                </div>

                <div class="input-group">
                    <!--<i class='bx bxs-user'></i>-->
                    <input type="text" id="price " name="price" placeholder="Expected price">
                </div>

                <div class="input-group">
                    <!--<i class='bx bxs-user'></i>-->
                    <input type="File" class="form-control form-control-s" name="pic" placeholder="Choose Car_Rc Image">
                </div>

                <div>
                    <!-- <center> -->
                    <button class="bottom" type="submit" name="submit">Submit</button>
                    <!-- </center> -->
                </div>

                <!-- <div class="input-group1">
                    <i class='bx bxs-user'></i>
                    <input type="submit" name="submit" value="Submit">
                </div> -->
                </form>

                <!--</form>-->
            </div>
        </div>

        <script>
            // Get references to input fields and result paragraph
            const kilometerInput = document.getElementById('kilometer');
            const userPriceInput = document.getElementById('userPrice');
            const resultParagraph = document.getElementById('result');

            // Attach event listeners to input fields
            kilometerInput.addEventListener('input', calculateCarPrice);
            userPriceInput.addEventListener('input', calculateCarPrice);

            function calculateCarPrice() {
                const kilometer = parseFloat(kilometerInput.value);
                const userPrice = parseFloat(userPriceInput.value);

                if (isNaN(kilometer) || isNaN(userPrice)) {
                    resultParagraph.innerText = "Please enter valid numbers.";
                    return;
                }

                const reducedPrice = userPrice - (kilometer * 2);
                resultParagraph.innerText = `The car's price based on ${kilometer} kilometers is $${(reducedPrice.toFixed() < 0) ? 0 : reducedPrice.toFixed()}`;
            }
        </script>

    </body>

</html>