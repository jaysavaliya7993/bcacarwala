<?php
session_start();
$email = $_SESSION['u_email'];
//$role = $_SESSION['role'];
?>

<html>

<head>
    <title>BCACARWALA</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- link to css -->
    <link rel="stylesheet" href="../cssfolder/home.css">
    <!--<link rel="stylesheet" href="../cssfolder/new.scss">-->

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../cssfolder/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <!--<link href="../cssfolder/styleee.css" rel="stylesheet">-->

    <style>
        .img-fluid {
            max-width: 50%;
            height: 45%;
        }
    </style>
</head>

<body>
    <nav class="navbar sticky-top navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <?php $id = $_GET['u_id'] ?>
            <a class="navbar-brand" href="../carfolder/Homepage.php?u_id=<?php echo $id; ?>">BCACARWALA</a>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">New Car</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Search new Car</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Latest Car</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Upcoming Car</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Electric Car</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Suggest Me A Car</a></li>
                        </ul>
                    </li>
                    <?php $id = $_GET['u_id'] ?>
                    <?php
                    // $id = $row['u_id']
                    ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">Used Car</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li class="dropdown-submenu">
                            <li><a class="dropdown-item" href="#">Sell Car In Your City</a>
                                <ul class="submenu dropdown-menu dropdown-menu-left">
                                    <li><a class="dropdown-item" href="#">Mota Varachha</a></li>
                                    <li><a class="dropdown-item" href="#">Hirabag</a></li>
                                    <li><a class="dropdown-item" href="#">Jakat Naka</a></li>
                                    <li><a class="dropdown-item" href="#">Sachin</a></li>
                                    <li><a class="dropdown-item" href="#">Udhana</a></li>
                                    <li><a class="dropdown-item" href="#">Vesu</a></li>
                                    <li><a class="dropdown-item" href="#">Dumas</a></li>
                                </ul>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="carupload.php?u_id=<?php echo $id; ?>">Sell Used Car</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="viewcar.php?u_id=<?php echo $id; ?>">Bcw Used car</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">My Listing</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">Sell Car</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Sell Car In Your City</a>
                                <ul class="submenu dropdown-menu dropdown-menu-left">
                                    <li><a class="dropdown-item" href="#">Mota Varachha</a></li>
                                    <li><a class="dropdown-item" href="#">Hirabag</a></li>
                                    <li><a class="dropdown-item" href="#">Jakat Naka</a></li>
                                    <li><a class="dropdown-item" href="#">Sachin</a></li>
                                    <li><a class="dropdown-item" href="#">Udhana</a></li>
                                    <li><a class="dropdown-item" href="#">Vesu</a></li>
                                    <li><a class="dropdown-item" href="#">Dumas</a></li>
                                </ul>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Sell Car By Brand</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">How it Works?</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">FAQS?</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">Popular Brand</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li>
                                <a class="dropdown-item" href="#">Tata</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Maruti Suzuki</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Huyndai</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Mahindra</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Kia</a></li>
                        </ul>
                    </li>
                </ul>

                <?php $id = $_GET['u_id'] ?>
                <form class="form">
                    <nav class="navvv">
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav  mb-2 mb-lg-0">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        <?php
                                        // USERNAME CODE<!--session code-->
                                        $conn = new mysqli('localhost', 'root', '', 'bcw');
                                        if ($conn->connect_error) {
                                            die("Connection Faield" . $conn->connect_error);
                                        }
                                        $sql = "SELECT * FROM tbl_m_user WHERE u_email = '$email'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                echo '<style="text-align: left"><b>' . $row['u_username'] . ' ' . '</b></a>';
                                                $id = $row['u_id'];
                                            }
                                        }
                                        ?>
                                    </a>

                                    <ul class="dropdown-menu dropdown-menu-end"
                                        aria-labelledby="navbarDropdownMenuAvatar">
                                        <li>
                                            <a class="dropdown-item">
                                                <?php
                                                // USERNAME CODE<!--session code-->
                                                $conn = new mysqli('localhost', 'root', '', 'bcw');
                                                if ($conn->connect_error) {
                                                    die("Connection Faield" . $conn->connect_error);
                                                }
                                                $sql = "SELECT * FROM tbl_m_user WHERE u_email = '$email'";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo '<style="text-align: left"><b>' . $row['role'] . ' ' . '</b></a>';
                                                        $id = $row['u_id'];
                                                    }
                                                }
                                                ?>
                                            </a>
                                        </li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li>
                                            <a class="dropdown-item"
                                                href="../userfolder/viewprofile.php?u_id=<?php echo $id; ?>">View
                                                Profile</a>
                                        </li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li>
                                            <a class="dropdown-item"
                                                href="../userfolder/managecar.php?u_id=<?php echo $id; ?>">Mange Car
                                                Details</a>
                                        </li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="../userfolder/forgot.php">Change Password
                                            </a>
                                        </li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="../userfolder/M_User.php">Logout</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </form>
            </div>
        </div>
    </nav>

    <!-- header end -->


    <style>
        .img-fluid {
            max-width: 150%;
            height: 300px;
        }

        .car-container {
            display: flex;
            align-items: center;
        }

        .car-image {
            flex: 1;
            /*width: 400px;*/
            height: 500px;
            padding: 120px;
        }

        .car-info {
            flex: 2;
            padding-left: 40px;
        }
    </style>


    <?php
    include 'connection.php';

    $u_id = $_GET['u_id'];
    $c_id = $_GET['c_id'];

    $query = "SELECT * FROM tbl_m_car WHERE c_id = $c_id";
    $loo = mysqli_query($db, $query);

    if (mysqli_num_rows($loo) > 0) {

        $row = mysqli_fetch_assoc($loo);
        $c_image = $row['c_image'];
        $c_no = $row['c_no'];
        $c_vin_no = $row['c_vin_no'];
        $c_company_name = $row['c_company_name'];
        $c_model = $row["c_model"];
        $c_version = $row['c_version'];
        $c_make_year = $row['c_make_year'];
        $c_make_month = $row['c_make_month'];
        $c_color = $row['c_color'];
        $c_seating_cap = $row['c_seating_cap'];
        $c_fule_type = $row['c_fule_type'];
        $c_transmis_type = $row['c_transmis_type'];
        $c_insurance_type = $row['c_insurance_type'];
        $c_no_of_owner = $row['c_no_of_owner'];
        //            $c_selling_date = $row['c_selling_date'];
//            $kilometer = $row['kilometer'];
//            $price = $row['price'];
    
        echo '<div class = "car-container">';
        echo '<div class="car-image">
        <img class="img-fluid" src="' . $c_image . '" alt="car image" ;">
        </div>';
        echo '<div class="car-info">';
        echo '<h2>Compant Name : ' . $c_company_name . '</h2><br>';
        echo '<p> Car Vhical Indentification Number: ' . $c_vin_no . '</p>';
        echo '<p>Car Number: ' . $c_no . ' &nbsp;&nbsp;&nbsp;&nbsp; Car Color: ' . $c_color . '</p>';
        echo '<p>CAr Making Year: ' . $c_make_year . '  &nbsp;&nbsp;&nbsp;&nbsp; Car Month: ' . $c_make_month . '</p>';
        echo '<p>Car no of woner: ' . $c_no_of_owner . '&nbsp;&nbsp;&nbsp;&nbsp; Covered Parking: ' . $c_transmis_type . '</p>';
        echo '<p>Insurance Type: ' . $c_insurance_type . '&nbsp;&nbsp;&nbsp;&nbsp; Seating cap: ' . $c_seating_cap . '</p>';
        echo '<button onclick="window.location.href=\'Homepage.php?u_id=' . htmlspecialchars($u_id) . '\'" style="background-color: #33d6ff;">Back to Page</button>';
        echo '</div>';
    } else {
        echo "car not found.";
    }
    ?>
    <!--//        &nbsp;&nbsp;&nbsp;&nbsp;  Car Kilometer: ' . $c_kilometer .-->
</body>

</html>