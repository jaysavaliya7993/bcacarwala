
<?php

session_start();
$email = $_SESSION['u_email'];
//$username = $_POST['u_username'];

//$role = $_SESSION['role'];


use PHPMailer\PHPMailer\PHPMailer;

include 'connection.php';
$result = false;
//$uploadFolder = 'uploads/'; // Specify the folder where you want to store the images

if (isset($_POST['submit']) && isset($_FILES["pic"])) {
    $id = $_GET['u_id'];
    $c_no = $_POST['c_no'];
    $c_vin_no = $_POST['c_vin_no'];
    $c_company_name = $_POST['c_company_name'];
    $c_model = $_POST["c_model"];
    $c_version = $_POST['c_version'];
    $c_make_year = $_POST['c_make_year'];
    $c_make_month = $_POST['c_make_month'];
    $c_color = $_POST['c_color'];
    $c_seating_cap = $_POST['c_seating_cap'];
    $c_fule_type = $_POST['c_fule_type'];
    $c_transmis_type = $_POST['c_transmis_type'];
    $c_insurance_type = $_POST['c_insurance_type'];
    $c_no_of_owner = $_POST['c_no_of_owner'];
//    $c_selling_date = $_POST['c_selling_date'];
    $kilometer = $_POST['kilometer'];
    $price = $_POST['price'];
//$c_image = $_POST['files'];
// $c_no_of_owner = $_POST['Insurance'];

//$file = $_FILES["pic"]["name"];
//$file_tmp = $_FILES["pic"]["tmp_name"];
//$targetPath = $uploadFolder . $file; // Define the target path for the uploaded image

//if (move_uploaded_file($file_tmp, $targetPath)) {
//    // File was successfully uploaded and moved to the folder
//    $path = $targetPath; // Update the path variable with the target path
//} else {
//    // Handle the case where the file upload failed
//    echo "File upload failed.";
//}


     $file = $_FILES["pic"]["name"];
     $file_tmp = $_FILES["pic"]["tmp_name"];
     move_uploaded_file($file_tmp, "" . $file);
     $path = "$file";
// Include the database configuration file 
    $sql = "INSERT INTO `tbl_m_car` (`c_no`, `c_vin_no`, `c_company_name`, `c_model`, `c_version`, `c_make_year`, `c_make_month`, `c_fule_type`, `c_transmis_type`, `c_color`, `c_seating_cap`, `c_insurance_type`, `c_no_of_owner`, `c_image`, `c_kilometer`, `c_price`) VALUES ('$c_no', '$c_vin_no', '$c_company_name', '$c_model', '$c_version', '$c_make_year', '$c_make_month', '$c_fule_type', '$c_transmis_type', '$c_color', '$c_seating_cap', '$c_insurance_type', '$c_no_of_owner','$Path', '$kilometer', '$price')";

    $result = mysqli_query($db, $sql);
}

//function validateVIN($c_vin_no) {
//    $response = array(); // Create an empty associative array for the response
//
//    // Remove any spaces or non-alphanumeric characters from the VIN
//    $cleanedVIN = preg_replace('/[^a-zA-Z0-9]/', '', $c_vin_no);
//
//    // Check if the cleaned VIN has exactly 17 characters
//    if (strlen($cleanedVIN) !== 17) {
//        $response['valid'] = false; // Set the 'valid' key to false
//        $response['message'] = 'Invalid VIN'; // Set a message
//    } else {
//        // Define a regular expression pattern for VIN validation
//        $pattern = '/^[A-HJ-NPR-Z0-9]{17}$/i';
//
//        // Perform the regular expression match
//        if (preg_match($pattern, $cleanedVIN)) {
//            $response['valid'] = true; // Set the 'valid' key to true for a valid VIN
//            $response['message'] = 'Valid VIN'; // Set a message
//        } else {
//            $response['valid'] = false; // Set the 'valid' key to false for an invalid VIN
//            $response['message'] = 'Invalid VIN'; // Set a message
//        }
//    }
//
//    // Encode the response array to JSON format
//    echo json_encode($response);
//}

// Get the VIN number from a POST request
//$c_vin_no = $_POST['c_vin_no'];
//
//// Call the validation function
//validateVIN($c_vin_no);


require 'PHPMailer/vendor/autoload.php'; // library's file

$mail = new PHPMailer(true); // PHPMailer obj
$mail->isSMTP(); // method
$mail->Host = 'smtp.gmail.com'; // host id
$mail->Port = 465; // for sending msg
$mail->SMTPSecure = 'ssl'; // for establish connection in gmail
$mail->CharSet = 'utf-8'; // encoding form ma 
$mail->SMTPAuth = true; // configure the established connection
$mail->Username = 'bcacarwala185@gmail.com'; // admin's mail id for sending msg
$mail->Password = 'hetiwlqarjytnllb'; // app password from google
$mail->SetFrom('bcacarwala185@gmail.com', 'bcacarwala185'); // source 
$mail->addAddress("$email"); // destination
$mail->addReplyTo('bcacarwala185@gmail.com', 'bcacarwala185'); // for replying in mail
$mail->SMTPDebug = false; // for finding error.
$mail->IsHTML(true);
$mailmessage = '
         <html>
         <head>
             <title>Mail</title>
             <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
         </head>
         
             <body style="width: 100%; font-family: \'Inter\', sans-serif; margin: 0; padding: 0; background-color: #ffffff;">
                <h2>Welcome to our systumm and thankyou for proveide details</h2>
             </body>
         </html>';

$mail->Subject = '';
$mail->Body = $mailmessage;
if ($mail->send()) {
//        header("location:verify.php");
//    } else {
             echo "<script language=\"JavaScript\">\n";
                echo "alert('Your data has been successfully submitted.');\n";
                echo "window.location='../carfolder/Homepage.php?u_id=<?php echo$id ?>'";
                echo "</script>";
    }
?>