<?php

include 'connection.php';
$id = $_GET['u_id'];

$query = "SELECT * FROM tbl_m_car WHERE c_id='$id'";
$result = mysqli_query($conn, $query);

if (isset($_GET['c_id'])) {
    $cid = $_GET['c_id'];

    // Delete the property from the database
    $deleteQuery = "DELETE FROM tbl_m_car WHERE c_id='$cid'";
    $result = mysqli_query($conn, $deleteQuery);

    if ($result) {
        // Property deleted successfully
        echo "Property deleted successfully.";
        header("Location: managecar.php?u_id=$id");
        exit();
    } else {
        // Error occurred while deleting the property
        echo "Error deleting property.";
        // Redirect the user to an error page or any appropriate page
        header("Location: error.php");
        exit();
    }
} else {
    // Invalid property ID
    echo "Invalid property ID.";
    // Redirect the user to an error page or any appropriate page
    header("Location: error.php");
    exit();
}
?>
