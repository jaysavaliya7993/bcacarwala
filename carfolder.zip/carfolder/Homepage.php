<?php
session_start();
$email = $_SESSION['u_email'];

//  $user_id = $_GET['u_id'];
?>

<html>

    <head>
        <meta charset="UTF-8">
        <title> Upload Car Page</title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

        <link rel="stylesheet" href="../cssfolder/home.css">
        <!--<link rel="stylesheet" href="../cssfolder/new.scss">-->

        <!--<link href="../cssfolder/styl.css" rel="stylesheet">-->

        <style>

        </style>
    </head>

    <body>
        <nav class="navbar sticky-top navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <?php $id = $_GET['u_id'] ?>
                <a class="navbar-brand" href="../carfolder/Homepage.php?u_id=<?php echo $id; ?>">BCACARWALA</a>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Home</a>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">New Car</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#">Search new Car</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Latest Car</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Upcoming Car</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Electric Car</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Suggest Me A Car</a></li>
                            </ul>
                        </li>
                        <?php $id = $_GET['u_id'] ?>
                        <?php
                        // $id = $row['u_id']
                        ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">Used Car</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li class="dropdown-submenu">
                                <li><a class="dropdown-item" href="#">Sell Car In Your City</a>
                                    <ul class="submenu dropdown-menu dropdown-menu-left">
                                        <li><a class="dropdown-item" href="#">Mota Varachha</a></li>
                                        <li><a class="dropdown-item" href="#">Hirabag</a></li>
                                        <li><a class="dropdown-item" href="#">Jakat Naka</a></li>
                                        <li><a class="dropdown-item" href="#">Sachin</a></li>
                                        <li><a class="dropdown-item" href="#">Udhana</a></li>
                                        <li><a class="dropdown-item" href="#">Vesu</a></li>
                                        <li><a class="dropdown-item" href="#">Dumas</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="carupload.php?u_id=<?php echo $id; ?>">Sell Used Car</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="viewcar.php?u_id=<?php echo $id; ?>">Bcw Used car</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">My Listing</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">Sell Car</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#">Sell Car In Your City</a>
                                    <ul class="submenu dropdown-menu dropdown-menu-left">
                                        <li><a class="dropdown-item" href="#">Mota Varachha</a></li>
                                        <li><a class="dropdown-item" href="#">Hirabag</a></li>
                                        <li><a class="dropdown-item" href="#">Jakat Naka</a></li>
                                        <li><a class="dropdown-item" href="#">Sachin</a></li>
                                        <li><a class="dropdown-item" href="#">Udhana</a></li>
                                        <li><a class="dropdown-item" href="#">Vesu</a></li>
                                        <li><a class="dropdown-item" href="#">Dumas</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Sell Car By Brand</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">How it Works?</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">FAQS?</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">Popular Brand</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li>
                                    <a class="dropdown-item" href="#">Tata</a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Maruti Suzuki</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Huyndai</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Mahindra</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Kia</a></li>
                            </ul>
                        </li>
                    </ul>

                    <?php $id = $_GET['u_id'] ?>
                    <form class="form">
                        <nav class="navvv">
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav  mb-2 mb-lg-0">
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                           data-bs-toggle="dropdown" aria-expanded="false">
                                               <?php
                                               // USERNAME CODE<!--session code-->
                                               $conn = new mysqli('localhost', 'root', '', 'bcw');
                                               if ($conn->connect_error) {
                                                   die("Connection Faield" . $conn->connect_error);
                                               }
                                               $sql = "SELECT * FROM tbl_m_user WHERE u_email = '$email'";
                                               $result = $conn->query($sql);
                                               if ($result->num_rows > 0) {
                                                   while ($row = $result->fetch_assoc()) {
                                                       echo '<style="text-align: left"><b>' . $row['u_username'] . ' ' . '</b></a>';
                                                       $id = $row['u_id'];
                                                   }
                                               }
                                               ?>
                                        </a>

                                        <ul class="dropdown-menu dropdown-menu-end"
                                            aria-labelledby="navbarDropdownMenuAvatar">
                                            <li>
                                                <a class="dropdown-item">
                                                    <?php
                                                    // USERNAME CODE<!--session code-->
                                                    $conn = new mysqli('localhost', 'root', '', 'bcw');
                                                    if ($conn->connect_error) {
                                                        die("Connection Faield" . $conn->connect_error);
                                                    }
                                                    $sql = "SELECT * FROM tbl_m_user WHERE u_email = '$email'";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            echo '<style="text-align: left"><b>' . $row['role'] . ' ' . '</b></a>';
                                                            $id = $row['u_id'];
                                                        }
                                                    }
                                                    ?>
                                                </a>
                                            </li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="../userfolder/viewprofile.php?u_id=<?php echo $id; ?>">View Profile</a>
                                            </li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="../userfolder/managecar.php?u_id=<?php echo $id; ?>">Mange Car Details</a>
                                            </li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="../userfolder/forgot.php">Change Password </a>
                                            </li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="../userfolder/M_User.php">Logout</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </form>
                </div>
            </div>
        </nav>

        <!-- header end -->

        <!-- main body -->

        <div class="div">
            <div class="box">
                <b>
                    <h1>Find Your Right Car</h1>
                </b>
                <hr>
                <b><label class="rdi">By Budget
                        <input type="radio" class="rdi"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </label></b>
                <b><label class="rdi">By Brand
                        <input type="radio" class="rdi"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </label><br><b>
                        <select class="select">
                            <option value="slect budget">Select Budget</option>
                            <option value="1 - 5 Lakh">1 - 5 Lakh</option>
                            <option value="5 - 10 Lakh">5 - 10 Lakh</option>
                            <option value="10 - 15 Lakh">10 - 15 Lakh</option>
                            <option value="15 - 20 Lakh">15 - 20 Lakh</option>
                            <option value="20 - 35 Lakh">20 - 35 Lakh</option>
                            <option value="35 - 50 Lakh">35 - 50 Lakh</option>
                            <option value="50 Lakh - 1 Crore">50 Lakh - 1 Crore</option>
                            <option value="1 Crore Above">1 Crore Above</option>
                        </select><br>
                        <select class="select">
                            <option value="All Vehicale Type">All Vehicale Type</option>
                            <option value="Hatchback">Hatchback</option>
                            <option value="Sedan">Sedan</option>
                            <option value="Suv">Suv</option>
                            <option value="Muv">Muv</option>
                            <option value="luxuray">luxuray</option>
                            <option value="Hybrid">Hybrid</option>
                            <option value="Wagon">Wagon</option>
                            <option value="Coupe">Coupe</option>
                        </select><br>
                        <input class="btn btn-outline-info btnnn" type="submit" value="Search"><br>
                        <hr>
                        <a href="#" class="href" title="Advance Option">Advance Option->></a>
                        </div>
                        </div><br>

                        <style>
                            .maindiv {
                                background-color: rgba(17, 25, 40, 0.25);
                                border-radius: 12px;
                                border: 1px solid rgba(255, 255, 255, 0.125);
                                padding: 20px;
                                display: flex;
                                flex-direction: column;
                                /*align-items: center;*/
                                /*left: 5rem;*/
                            }

                            .lastdiv {
                                /*background-image: url(https://images.unsplash.com/photo-1641326201918-3cafc641038e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1887&q=80);*/
                                background-position: center;
                                /*display: flex;*/
                                background-size: cover;
                                height: 310px;
                                width: 100%;
                                border-radius: 12px;
                                border: 1px solid rgba(255,255,255, 0.255);
                            }

                            #h1{
                                /*font-family: 'Righteous', sans-serif;*/
                                color: rgba(255,255,255,0.98);
                                text-transform: uppercase;
                                font-size: 2.4rem;
                            }

                            #p {
                                color: #fff;
                                /*font-family: 'Lato', sans-serif;*/
                                text-align: center;
                                font-size: 0.8rem;
                                line-height: 100%;
                                /*letter-spacing: 2px;*/
                                text-transform: uppercase;
                            }

/*                            .img-fluid {
                                width: 100%;
                                height: 200px;
                                border-radius: 12px;
                                border: 1px solid rgba(255,255,255, 0.255);
                            }*/
                        </style>

                        <?php
                        include 'connection.php';

                        $id = $_GET['u_id'];

                        $query = "SELECT c_no,c_company_name,c_vin_no,c_model,c_image,c_no_of_owner,c_seating_cap,c_color,c_id FROM tbl_m_car";
                        $result = mysqli_query($db, $query);

                        if (mysqli_num_rows($result) > 0) {
                            echo '<div class="tab-content"><div id="tab-1" class="tab-pane fade show p-0 active"><div class="row g-4">';
                            while ($row = mysqli_fetch_assoc($result)) {
                                $c_image = $row['c_image'];
                                $c_no = $row['c_no'];
                                $c_company_name = $row['c_company_name'];
                                $c_vin_no = $row['c_vin_no'];
                                $c_model = $row["c_model"];
                                $c_no_of_owner = $row["c_no_of_owner"];
                                $c_seating_cap = $row["c_seating_cap"];
                                $c_color = $row["c_color"];
                                ?>

                                <div class="col-lg-4 col-md-6">
                                    <!--HTML code to display the car--> 
                                    <div class="rounded overflow-hidden">
                                        <div class="position-relative overflow-hidden">
                                            <div class="p-4 pb-0">

                                                <div class="maindiv">
                                                    <div class="wrapper">
                                                        <div class="lastdiv"> 
                                                            <a href="viewcar.php?u_id=<?php echo $id; ?>&c_id=<?php echo $row['c_id']; ?>">
                                                                <h7 class="text-primary mb-3"><img class="lastdiv" src="<?php echo $c_image; ?>"
                                                                                                   alt="car image"></h7>
                                                            </a>
                                                        </div>
                                                        <h1 id="h1"><?php echo $c_company_name; ?></h1>
                                                        <p id="p">Car Model :- <?php echo $c_model; ?><p>
                                                        <p id="p">Car No :- <?php echo $c_no; ?><p>
                                                        <p id="p">Car Color :- <?php echo $c_color; ?><p>  
                                                        <p id="p">Seating Cap :- <?php echo $c_seating_cap; ?><p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            echo '</div></div></div>';
                        } else {
                            echo "No cars found.";
                        }
                        ?>

                        <!-- Footer -->
                        <footer class="text-center text-lg-start bg-white text-muted">
                            <!-- Section: Social media -->
                            <section class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
                                <!-- Left -->
                                <div class="me-5 d-none d-lg-block">
                                    <!-- <span>Get connected with us on social networks:</span> -->
                                </div>
                                <!-- Left -->

                                <!-- Right -->
                                <div>
                                    <a href="" class="me-4 link-secondary">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                    <a href="" class="me-4 link-secondary">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                    <a href="" class="me-4 link-secondary">
                                        <i class="fab fa-google"></i>
                                    </a>
                                    <a href="" class="me-4 link-secondary">
                                        <i class="fab fa-instagram"></i>
                                    </a>
                                    <a href="" class="me-4 link-secondary">
                                        <i class="fab fa-linkedin"></i>
                                    </a>
                                    <a href="" class="me-4 link-secondary">
                                        <i class="fab fa-github"></i>
                                    </a>
                                </div>
                                <!-- Right -->
                            </section>
                            <!-- Section: Social media -->

                            <!-- Section: Links  -->
                            <section class="">
                                <div class="container text-center text-md-start mt-5">
                                    <!-- Grid row -->
                                    <div class="row mt-3">
                                        <!-- Grid column -->
                                        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
                                            <!-- Content -->
                                            <h6 class="text-uppercase fw-bold mb-4">
                                                <i class="fas fa-gem me-3 text-secondary"></i>BCACARWALA
                                            </h6>
                                            <p>
                                            <j>BCACARWALA is a website the buyer gets information about buying a car the and seller can
                                                upload his car detail for sale. Our aim is to provide buyers and sellers choose the
                                                right car and our interface is simple to understand buyer and seller.</j>
                                            </p>
                                        </div>
                                        <!-- Grid column -->

                                        <!-- Grid column -->
                                        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                                            <!-- Links -->
                                            <h6 class="text-uppercase fw-bold mb-4">
                                                Useful links
                                            </h6>
                                            <p>
                                                <a href="#!" class="text-reset">Pricing</a>
                                            </p>
                                            <p>
                                                <a href="#!" class="text-reset">Settings</a>
                                            </p>
                                            <p>
                                                <a href="#!" class="text-reset">Orders</a>
                                            </p>
                                            <p>
                                                <a href="#!" class="text-reset">Help</a>
                                            </p>
                                        </div>
                                        <!-- Grid column -->

                                        <!-- Grid column -->
                                        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                                            <!-- Links -->
                                            <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
                                            <p><i class="fas fa-home me-3 text-secondary"></i> Mhadev Chowk, surat, Gujarat.</p>
                                            <p>
                                                <i class="fas fa-envelope me-3 text-secondary"></i>
                                                bcacarwala185@gmail.com
                                            </p>
                                            <p><i class="fas fa-phone me-3 text-secondary"></i> + 91 6354769899</p>
                                            <p><i class="fas fa-print me-3 text-secondary"></i> + 91 7069218479</p>
                                        </div>
                                        <!-- Grid column -->
                                    </div>
                                    <!-- Grid row -->
                                </div>
                            </section>
                            <!-- Section: Links  -->

                            <!-- Copyright -->
                            <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.025);">
                                © 2021 Copyright:
                                <a class="text-reset fw-bold" href="https://buywaw.com/">BCACARWALA.com</a>
                            </div>
                            <!-- Copyright -->
                        </footer>
                        <!-- Footer -->

                        </body>

                        </html>