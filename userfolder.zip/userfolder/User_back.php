<?php
//$id = $_POST['u_id'];
$username = $_POST['username'];
$email = $_POST['email'];
$phone_no = $_POST['phone_no'];
$address = $_POST['address'];
$dob = $_POST['dob'];
$role = $_POST['role'];
$password = $_POST['password'];
$user_id = $_GET['u_id'];

//$con_password = $_POST['con_password'];
session_start();
$_SESSION['u_email'] = $email;

// database connect
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
     $email = $_POST['email'];

     // Validate email address
     if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
          // Check if email ends with "@email.com"
          if (substr($email, -10) == "@yahoo.com") 
          {
               //check password with 1 special ,1 numeric and 1 charecter in password
               if (preg_match('/^(?=.*[!@#$%^&*])(?=.*\d)(?=.*[a-z]).{8,}$/', $password)) 
               {
                    // Input is valid, do something here
                    // Email is valid, do something with it (send email, save to database, etc.)
                    $conn = new mysqli('localhost', 'root', '', 'bcw');
                    if ($conn->connect_error) 
                    {
                         die('Connection failed : ' . $conn->connect_error);
                    } 
                    else 
                    {
                         $sql = "insert into tbl_m_user(u_username,u_email,u_phone_no,u_address,u_dob,u_password,role) 
                          values ('$username','$email','$phone_no','$address','$dob','$password','$con_password','$role')";
                         $sqlquiry = mysqli_query($conn, $sql);
                         echo "<script language=\"JavaScript\">\n";
                         echo "alert('$username Your Registration has been sucessfully.');\n";
                         echo "window.location='../carfolder/Homepage.php'";
                         echo "</script>";
                         $conn->close();
                    }
               } 
               else 
               {
                    // Email is not valid, display an error message
                    echo "<script language=\"JavaScript\">\n";
                    // echo "alert('$username Your Password has need min 8 charecter and max 20 length in Password and need 1 charecter and need 1 special charecter and need 1 number in password. please try again.');\n";
                    echo "window.location='M_User.php'";
                    echo "</script>";
               }
          }
          // Check if email ends with "@gmail.com"
          else if (substr($email, -10) == "@gmail.com") 
          {
               //check password with 1 special ,1 numeric and 1 charecter in password
               if (preg_match('/^(?=.*[!@#$%^&*])(?=.*\d)(?=.*[a-z]).{8,}$/', $password)) 
               {
                    // Input is valid, do something here
                    // Email is valid, do something with it (send email, save to database, etc.)
                    $conn = new mysqli('localhost','root','','bcw');
                    if ($conn->connect_error) 
                    {
                         die('Connection failed : ' . $conn->connect_error);
                    } 
                    
                    else 
                    {
                         $sql = "insert into tbl_m_user(u_username,u_email,u_phone_no,u_address,u_dob,u_password,role) values ('$username','$email','$phone_no','$address','$dob','$password','$role')";
                         $sqlquiry = mysqli_query($conn, $sql);
                         echo "<script language=\"JavaScript\">\n";
                         echo "alert('$username Your Registration has been sucessfully.');\n";
                         echo "window.location='../carfolder/Homepage.php?u_id'";
                         echo "</script>";
                         $conn->close();
                    }
               }
               else 
               {
                    // password is not valid, display an error message
                    echo "<script language=\"JavaScript\">\n";
                    echo "alert('$username unsuccessfull.');\n";
                    echo "window.location='M_User.php'";
                    echo "</script>";
               }
          } 
          else 
          {
               // Email is not valid, display an error message
               echo "<script language=\"JavaScript\">\n";
               echo "alert('$username Your Email has been Invalid. Please Try Again.');\n";
               echo "window.location='M_User.php'";
               echo "</script>";
          }
     } 
//     else 
//     {
//          // Email is not valid, display an error message
//          echo "<script language=\"JavaScript\">\n";
//          echo "alert('$username Your Email has been Invalid. Please Try Again.');\n";
//          echo "window.location='M_User.php'";
//          echo "</script>";
//     }
}

?>