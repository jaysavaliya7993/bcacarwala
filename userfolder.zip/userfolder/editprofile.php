
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>BCACARWALA</title>

        <!-- Favicon -->
        <!--<link rel="shortcut icon" href="../assets/images/favicon.ico" />-->

        <!-- Library / Plugin Css Build -->
        <link rel="stylesheet" href="../cssfolder/libs.min.css" />

        <!-- Aos Animation Css -->
        <!--<link rel="stylesheet" href="../assets/vendor/aos/dist/aos.css" />-->

        <!-- Vrooom Design System Css -->
        <link rel="stylesheet" href="../cssfolder/vrooom.min.css?v=1.1.01" />

        <!-- Custom Css -->
        <link rel="stylesheet" href="../cssfolder/custom.min.css?v=1.1.01" />
    </head>
    <body class="  ">
        <span class="screen-darken backdrop"></span>

        <aside class="sidebar sidebar-default sidebar-two navs-pill sidebar-mini">
            <div class="sidebar-body pt-0 data-scrollbar">
                <div class="sidebar-list">
                    <ul class="navbar-nav iq-main-menu nav nav-tabs" id="sidebar-menu" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="../dashboard/index.html" data-sidebar-toggle="tooltip" data-bs-placement="right" title="Dashboard">
                                <i class="icon">
                                    <svg width="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path opacity="0.4" d="M16.0756 2H19.4616C20.8639 2 22.0001 3.14585 22.0001 4.55996V7.97452C22.0001 9.38864 20.8639 10.5345 19.4616 10.5345H16.0756C14.6734 10.5345 13.5371 9.38864 13.5371 7.97452V4.55996C13.5371 3.14585 14.6734 2 16.0756 2Z" fill="currentColor"></path>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M4.53852 2H7.92449C9.32676 2 10.463 3.14585 10.463 4.55996V7.97452C10.463 9.38864 9.32676 10.5345 7.92449 10.5345H4.53852C3.13626 10.5345 2 9.38864 2 7.97452V4.55996C2 3.14585 3.13626 2 4.53852 2ZM4.53852 13.4655H7.92449C9.32676 13.4655 10.463 14.6114 10.463 16.0255V19.44C10.463 20.8532 9.32676 22 7.92449 22H4.53852C3.13626 22 2 20.8532 2 19.44V16.0255C2 14.6114 3.13626 13.4655 4.53852 13.4655ZM19.4615 13.4655H16.0755C14.6732 13.4655 13.537 14.6114 13.537 16.0255V19.44C13.537 20.8532 14.6732 22 16.0755 22H19.4615C20.8637 22 22 20.8532 22 19.44V16.0255C22 14.6114 20.8637 13.4655 19.4615 13.4655Z" fill="currentColor"></path>
                                    </svg>
                                </i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-panel " href="#sidebar-auths" id="auth-pages" data-bs-toggle="tab" data-sidebar-toggle="tooltip" data-bs-placement="right" data-bs-target="#sidebar-auths" role="tab" aria-controls="sidebar-auth" aria-selected="true" title="Authentication">
                                <i class="icon">
                                    <svg width="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path opacity="0.4" d="M12.0865 22C11.9627 22 11.8388 21.9716 11.7271 21.9137L8.12599 20.0496C7.10415 19.5201 6.30481 18.9259 5.68063 18.2336C4.31449 16.7195 3.5544 14.776 3.54232 12.7599L3.50004 6.12426C3.495 5.35842 3.98931 4.67103 4.72826 4.41215L11.3405 2.10679C11.7331 1.96656 12.1711 1.9646 12.5707 2.09992L19.2081 4.32684C19.9511 4.57493 20.4535 5.25742 20.4575 6.02228L20.4998 12.6628C20.5129 14.676 19.779 16.6274 18.434 18.1581C17.8168 18.8602 17.0245 19.4632 16.0128 20.0025L12.4439 21.9088C12.3331 21.9686 12.2103 21.999 12.0865 22Z" fill="currentColor"></path>
                                    <path d="M11.3194 14.3209C11.1261 14.3219 10.9328 14.2523 10.7838 14.1091L8.86695 12.2656C8.57097 11.9793 8.56795 11.5145 8.86091 11.2262C9.15387 10.9369 9.63207 10.934 9.92906 11.2193L11.3083 12.5451L14.6758 9.22479C14.9698 8.93552 15.448 8.93258 15.744 9.21793C16.041 9.50426 16.044 9.97004 15.751 10.2574L11.8519 14.1022C11.7049 14.2474 11.5127 14.3199 11.3194 14.3209Z" fill="currentColor"></path>
                                    </svg>
                                </i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-panel " href="#sidebar-users" id="users-pages" data-bs-toggle="tab" data-sidebar-toggle="tooltip" data-bs-placement="right" data-bs-target="#sidebar-users" role="tab" aria-controls="sidebar-users" aria-selected="false" title="Users">
                                <i class="icon">
                                    <svg width="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M11.9488 14.54C8.49884 14.54 5.58789 15.1038 5.58789 17.2795C5.58789 19.4562 8.51765 20.0001 11.9488 20.0001C15.3988 20.0001 18.3098 19.4364 18.3098 17.2606C18.3098 15.084 15.38 14.54 11.9488 14.54Z" fill="currentColor"></path>
                                    <path opacity="0.4" d="M11.949 12.467C14.2851 12.467 16.1583 10.5831 16.1583 8.23351C16.1583 5.88306 14.2851 4 11.949 4C9.61293 4 7.73975 5.88306 7.73975 8.23351C7.73975 10.5831 9.61293 12.467 11.949 12.467Z" fill="currentColor"></path>
                                    <path opacity="0.4" d="M21.0881 9.21923C21.6925 6.84176 19.9205 4.70654 17.664 4.70654C17.4187 4.70654 17.1841 4.73356 16.9549 4.77949C16.9244 4.78669 16.8904 4.802 16.8725 4.82902C16.8519 4.86324 16.8671 4.90917 16.8895 4.93889C17.5673 5.89528 17.9568 7.0597 17.9568 8.30967C17.9568 9.50741 17.5996 10.6241 16.9728 11.5508C16.9083 11.6462 16.9656 11.775 17.0793 11.7948C17.2369 11.8227 17.3981 11.8371 17.5629 11.8416C19.2059 11.8849 20.6807 10.8213 21.0881 9.21923Z" fill="currentColor"></path>
                                    <path d="M22.8094 14.817C22.5086 14.1722 21.7824 13.73 20.6783 13.513C20.1572 13.3851 18.747 13.205 17.4352 13.2293C17.4155 13.232 17.4048 13.2455 17.403 13.2545C17.4003 13.2671 17.4057 13.2887 17.4316 13.3022C18.0378 13.6039 20.3811 14.916 20.0865 17.6834C20.074 17.8032 20.1698 17.9068 20.2888 17.8888C20.8655 17.8059 22.3492 17.4853 22.8094 16.4866C23.0637 15.9589 23.0637 15.3456 22.8094 14.817Z" fill="currentColor"></path>
                                    <path opacity="0.4" d="M7.04459 4.77973C6.81626 4.7329 6.58077 4.70679 6.33543 4.70679C4.07901 4.70679 2.30701 6.84201 2.9123 9.21947C3.31882 10.8216 4.79355 11.8851 6.43661 11.8419C6.60136 11.8374 6.76343 11.8221 6.92013 11.7951C7.03384 11.7753 7.09115 11.6465 7.02668 11.551C6.3999 10.6234 6.04263 9.50765 6.04263 8.30991C6.04263 7.05904 6.43303 5.89462 7.11085 4.93913C7.13234 4.90941 7.14845 4.86348 7.12696 4.82926C7.10906 4.80135 7.07593 4.78694 7.04459 4.77973Z" fill="currentColor"></path>
                                    <path d="M3.32156 13.5127C2.21752 13.7297 1.49225 14.1719 1.19139 14.8167C0.936203 15.3453 0.936203 15.9586 1.19139 16.4872C1.65163 17.4851 3.13531 17.8066 3.71195 17.8885C3.83104 17.9065 3.92595 17.8038 3.91342 17.6832C3.61883 14.9167 5.9621 13.6046 6.56918 13.3029C6.59425 13.2885 6.59962 13.2677 6.59694 13.2542C6.59515 13.2452 6.5853 13.2317 6.5656 13.2299C5.25294 13.2047 3.84358 13.3848 3.32156 13.5127Z" fill="currentColor"></path>
                                    </svg>
                                </i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link "href="icons/dual-tone.html" data-sidebar-toggle="tooltip" data-bs-placement="right" data-bs-target="#sidebar-icons" aria-selected="false" title="About">
                                <i class="icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M8 10.5378C8 9.43327 8.89543 8.53784 10 8.53784H11.3333C12.4379 8.53784 13.3333 9.43327 13.3333 10.5378V19.8285C13.3333 20.9331 14.2288 21.8285 15.3333 21.8285H16C16 21.8285 12.7624 23.323 10.6667 22.9361C10.1372 22.8384 9.52234 22.5913 9.01654 22.3553C8.37357 22.0553 8 21.3927 8 20.6832V10.5378Z" fill="currentColor"/>
                                    <rect opacity="0.4" x="8" y="1" width="5" height="5" rx="2.5" fill="currentColor"/>
                                    </svg>
                                </i>
                            </a>
                        </li>
                    </ul>        
                </div>
            </div>
        </aside>
        <!-- Sidebar Menu start                                                                                                                                                                                                                                              -->
        <div class="tab-content sidebar sidebar-default navs-rounded-all  in-active " id="nav-tabContent"> 
            <div class="sidebar-header d-flex align-items-center justify-content-start">

            </div>
            <div class="tab-pane fade show active" id="sidebar-auths" role="tabpanel" aria-labelledby="auth-pages">
                <div class="sidebar-body">
                    <ul class="navbar-nav" id="sidebar-menu-auth">
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="collapse" href="#sidebar-auth" role="button" aria-expanded="true" aria-controls="sidebar-menu-auth">
                                <i class="icon">
                                    <svg width="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path opacity="0.4" d="M12.0865 22C11.9627 22 11.8388 21.9716 11.7271 21.9137L8.12599 20.0496C7.10415 19.5201 6.30481 18.9259 5.68063 18.2336C4.31449 16.7195 3.5544 14.776 3.54232 12.7599L3.50004 6.12426C3.495 5.35842 3.98931 4.67103 4.72826 4.41215L11.3405 2.10679C11.7331 1.96656 12.1711 1.9646 12.5707 2.09992L19.2081 4.32684C19.9511 4.57493 20.4535 5.25742 20.4575 6.02228L20.4998 12.6628C20.5129 14.676 19.779 16.6274 18.434 18.1581C17.8168 18.8602 17.0245 19.4632 16.0128 20.0025L12.4439 21.9088C12.3331 21.9686 12.2103 21.999 12.0865 22Z" fill="currentColor"></path>
                                    <path d="M11.3194 14.3209C11.1261 14.3219 10.9328 14.2523 10.7838 14.1091L8.86695 12.2656C8.57097 11.9793 8.56795 11.5145 8.86091 11.2262C9.15387 10.9369 9.63207 10.934 9.92906 11.2193L11.3083 12.5451L14.6758 9.22479C14.9698 8.93552 15.448 8.93258 15.744 9.21793C16.041 9.50426 16.044 9.97004 15.751 10.2574L11.8519 14.1022C11.7049 14.2474 11.5127 14.3199 11.3194 14.3209Z" fill="currentColor"></path>
                                    </svg>
                                </i>
                                <span class="item-name">Authentication</span>
                                <i class="right-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                    </svg>
                                </i>
                            </a>
                            <ul class="sub-nav collapse show" id="sidebar-auth" data-bs-parent="#sidebar-menu-auth">
                                <li class="nav-item">
                                    <a class="nav-link" href="M_User.php">
                                        <i class="icon"></i>
                                        <span class="item-name">Register</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="M_User.php">
                                        <i class="icon"></i>
                                        <span class="item-name">Login</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="forgot.php">
                                        <i class="icon"></i>
                                        <span class="item-name">Recover password</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="tab-pane fade" id="sidebar-users" role="tabpanel" aria-labelledby="users-pages">
                <div class="sidebar-body">
                    <ul class="navbar-nav" id="sidebar-menu-users">
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="collapse" href="#sidebar-user" role="button" aria-expanded="true" aria-controls="sidebar-menu-users">
                                <i class="icon">
                                    <svg width="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M11.9488 14.54C8.49884 14.54 5.58789 15.1038 5.58789 17.2795C5.58789 19.4562 8.51765 20.0001 11.9488 20.0001C15.3988 20.0001 18.3098 19.4364 18.3098 17.2606C18.3098 15.084 15.38 14.54 11.9488 14.54Z" fill="currentColor"></path>
                                    <path opacity="0.4" d="M11.949 12.467C14.2851 12.467 16.1583 10.5831 16.1583 8.23351C16.1583 5.88306 14.2851 4 11.949 4C9.61293 4 7.73975 5.88306 7.73975 8.23351C7.73975 10.5831 9.61293 12.467 11.949 12.467Z" fill="currentColor"></path>
                                    <path opacity="0.4" d="M21.0881 9.21923C21.6925 6.84176 19.9205 4.70654 17.664 4.70654C17.4187 4.70654 17.1841 4.73356 16.9549 4.77949C16.9244 4.78669 16.8904 4.802 16.8725 4.82902C16.8519 4.86324 16.8671 4.90917 16.8895 4.93889C17.5673 5.89528 17.9568 7.0597 17.9568 8.30967C17.9568 9.50741 17.5996 10.6241 16.9728 11.5508C16.9083 11.6462 16.9656 11.775 17.0793 11.7948C17.2369 11.8227 17.3981 11.8371 17.5629 11.8416C19.2059 11.8849 20.6807 10.8213 21.0881 9.21923Z" fill="currentColor"></path>
                                    <path d="M22.8094 14.817C22.5086 14.1722 21.7824 13.73 20.6783 13.513C20.1572 13.3851 18.747 13.205 17.4352 13.2293C17.4155 13.232 17.4048 13.2455 17.403 13.2545C17.4003 13.2671 17.4057 13.2887 17.4316 13.3022C18.0378 13.6039 20.3811 14.916 20.0865 17.6834C20.074 17.8032 20.1698 17.9068 20.2888 17.8888C20.8655 17.8059 22.3492 17.4853 22.8094 16.4866C23.0637 15.9589 23.0637 15.3456 22.8094 14.817Z" fill="currentColor"></path>
                                    <path opacity="0.4" d="M7.04459 4.77973C6.81626 4.7329 6.58077 4.70679 6.33543 4.70679C4.07901 4.70679 2.30701 6.84201 2.9123 9.21947C3.31882 10.8216 4.79355 11.8851 6.43661 11.8419C6.60136 11.8374 6.76343 11.8221 6.92013 11.7951C7.03384 11.7753 7.09115 11.6465 7.02668 11.551C6.3999 10.6234 6.04263 9.50765 6.04263 8.30991C6.04263 7.05904 6.43303 5.89462 7.11085 4.93913C7.13234 4.90941 7.14845 4.86348 7.12696 4.82926C7.10906 4.80135 7.07593 4.78694 7.04459 4.77973Z" fill="currentColor"></path>
                                    <path d="M3.32156 13.5127C2.21752 13.7297 1.49225 14.1719 1.19139 14.8167C0.936203 15.3453 0.936203 15.9586 1.19139 16.4872C1.65163 17.4851 3.13531 17.8066 3.71195 17.8885C3.83104 17.9065 3.92595 17.8038 3.91342 17.6832C3.61883 14.9167 5.9621 13.6046 6.56918 13.3029C6.59425 13.2885 6.59962 13.2677 6.59694 13.2542C6.59515 13.2452 6.5853 13.2317 6.5656 13.2299C5.25294 13.2047 3.84358 13.3848 3.32156 13.5127Z" fill="currentColor"></path>
                                    </svg>
                                </i>
                                <span class="item-name">Users</span>
                                <i class="right-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                    </svg>
                                </i>
                            </a>
                            <ul class="sub-nav collapse show" id="sidebar-user" data-bs-parent="#sidebar-menu-users">
                                <li class="nav-item">
                                    <a class="nav-link " href="userprofile.php">
                                        <i class="icon"></i>
                                        <span class="item-name">User Profile</span>
                                    </a>
                                    <!--                                </li>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link " href="../dashboard/app/user-add.html">
                                                                            <i class="icon"></i>
                                                                            <span class="item-name">Add User</span>
                                                                        </a>
                                                                    </li>-->
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Sidebar Menu End -->    
        <main class="main-content">
            <div class="position-relative">
                <!--Nav Start-->
                <nav class="nav navbar navbar-expand-lg navbar-light iq-navbar">
                    <div class="container-fluid navbar-inner">

                        <div class="input-group search-input">
                            <span class="input-group-text" id="search-input">
                                <svg width="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="11.7669" cy="11.7666" r="8.98856" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></circle>
                                <path d="M18.0186 18.4851L21.5426 22" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                            </span>
                            <input type="search" class="form-control" placeholder="Search...">
                        </div>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon">
                                <span class="navbar-toggler-bar bar1 mt-2"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto align-items-center navbar-list mb-2 mb-lg-0">

                                <li class="nav-item dropdown">
                                    <a href="#"  class="nav-link" id="notification-drop" data-bs-toggle="dropdown" >
                                        <svg width="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M19.7695 11.6453C19.039 10.7923 18.7071 10.0531 18.7071 8.79716V8.37013C18.7071 6.73354 18.3304 5.67907 17.5115 4.62459C16.2493 2.98699 14.1244 2 12.0442 2H11.9558C9.91935 2 7.86106 2.94167 6.577 4.5128C5.71333 5.58842 5.29293 6.68822 5.29293 8.37013V8.79716C5.29293 10.0531 4.98284 10.7923 4.23049 11.6453C3.67691 12.2738 3.5 13.0815 3.5 13.9557C3.5 14.8309 3.78723 15.6598 4.36367 16.3336C5.11602 17.1413 6.17846 17.6569 7.26375 17.7466C8.83505 17.9258 10.4063 17.9933 12.0005 17.9933C13.5937 17.9933 15.165 17.8805 16.7372 17.7466C17.8215 17.6569 18.884 17.1413 19.6363 16.3336C20.2118 15.6598 20.5 14.8309 20.5 13.9557C20.5 13.0815 20.3231 12.2738 19.7695 11.6453Z" fill="currentColor"></path>
                                        <path opacity="0.4" d="M14.0088 19.2283C13.5088 19.1215 10.4627 19.1215 9.96275 19.2283C9.53539 19.327 9.07324 19.5566 9.07324 20.0602C9.09809 20.5406 9.37935 20.9646 9.76895 21.2335L9.76795 21.2345C10.2718 21.6273 10.8632 21.877 11.4824 21.9667C11.8123 22.012 12.1482 22.01 12.4901 21.9667C13.1083 21.877 13.6997 21.6273 14.2036 21.2345L14.2026 21.2335C14.5922 20.9646 14.8734 20.5406 14.8983 20.0602C14.8983 19.5566 14.4361 19.327 14.0088 19.2283Z" fill="currentColor"></path>
                                        </svg>
                                        <span class="bg-danger dots"></span>
                                    </a>

                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link py-0 d-flex align-items-center" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <img src="../userfolder/avatars/01.png" alt="User-Profile" class="img-fluid avatar avatar-50 avatar-rounded">
                                        <div class="caption ms-3 d-none d-md-block ">
                                            <h6 class="mb-0 caption-title">Austin Robertson</h6>
                                            <p class="mb-0 caption-sub-title">Marketing Administrator</p>
                                        </div>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <li><a class="dropdown-item" href="userprofile.php">Profile</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item" href="M_User.php">Logout</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>        
                <!--Nav End-->
            </div>
            <div class="conatiner-fluid content-inner mt-5 py-0">
                <div>
                    <div class="row">
                        <div class="col-xl-3 col-lg-4">
                            <div class="card">
                                <div class="card-header d-flex justify-content-between">
                                    <div class="header-title">
                                        <h4 class="card-title">Add New User</h4>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <form>
                                        <div class="form-group">
                                            <div class="profile-img-edit position-relative">
                                                <img class="profile-pic rounded avatar-100" src="../userfolder/avatars/01.png" alt="profile-pic">
                                                <div class="upload-icone bg-primary">
                                                    <svg class="upload-button" width="14" height="14" viewBox="0 0 24 24">
                                                    <path fill="#ffffff" d="M14.06,9L15,9.94L5.92,19H5V18.08L14.06,9M17.66,3C17.41,3 17.15,3.1 16.96,3.29L15.13,5.12L18.88,8.87L20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18.17,3.09 17.92,3 17.66,3M14.06,6.19L3,17.25V21H6.75L17.81,9.94L14.06,6.19Z" />
                                                    </svg>
                                                    <input class="file-upload" type="file" accept="image/*">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">User Role:</label>
                                            <select name="type" class="selectpicker form-control" data-style="py-0">
                                                <option>Select</option>
                                                <option>Web Designer</option>
                                                <option>Web Developer</option>
                                                <option>Tester</option>
                                                <option>Php Developer</option>
                                                <option>Ios Developer </option>
                                            </select>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-9 col-lg-8">
                            <div class="card">
                                <div class="card-header d-flex justify-content-between">
                                    <div class="header-title">
                                        <h4 class="card-title">New User Information</h4>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="new-user-info">
                                        <form>
                                            <div class="row">
                                                <div class="form-group col-md-6">
                                                    <label class="form-label" for="fname">First Name:</label>
                                                    <input type="text" class="form-control" id="fname" placeholder="First Name">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label class="form-label" for="lname">Last Name:</label>
                                                    <input type="text" class="form-control" id="lname" placeholder="Last Name">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label class="form-label" for="add1">Street Address 1:</label>
                                                    <input type="text" class="form-control" id="add1" placeholder="Street Address 1">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label class="form-label" for="add2">Street Address 2:</label>
                                                    <input type="text" class="form-control" id="add2" placeholder="Street Address 2">
                                                </div>
                                                <div class="form-group col-md-12">
                                                    <label class="form-label" for="cname">Company Name:</label>
                                                    <input type="text" class="form-control" id="cname" placeholder="Company Name">
                                                </div>
                                                <div class="form-group col-sm-12">
                                                    <label class="form-label">Country:</label>
                                                    <select name="type" class="selectpicker form-control" data-style="py-0">
                                                        <option>Select Country</option>
                                                        <option>Caneda</option>
                                                        <option>Noida</option>
                                                        <option >USA</option>
                                                        <option>India</option>
                                                        <option>Africa</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label class="form-label" for="mobno">Mobile Number:</label>
                                                    <input type="text" class="form-control" id="mobno" placeholder="Mobile Number">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label class="form-label" for="altconno">Alternate Contact:</label>
                                                    <input type="text" class="form-control" id="altconno" placeholder="Alternate Contact">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label class="form-label" for="email">Email:</label>
                                                    <input type="email" class="form-control" id="email" placeholder="Email">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label class="form-label" for="pno">Pin Code:</label>
                                                    <input type="text" class="form-control" id="pno" placeholder="Pin Code">
                                                </div>
                                                <div class="form-group col-md-12">
                                                    <label class="form-label" for="city">Town/City:</label>
                                                    <input type="text" class="form-control" id="city" placeholder="Town/City">
                                                </div>
                                            </div>
                                            <hr>
                                            <h5 class="mb-3">Security</h5>
                                            <div class="row">
                                                <div class="form-group col-md-12">
                                                    <label class="form-label" for="uname">User Name:</label>
                                                    <input type="text" class="form-control" id="uname" placeholder="User Name">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label class="form-label" for="pass">Password:</label>
                                                    <input type="password" class="form-control" id="pass" placeholder="Password">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label class="form-label" for="rpass">Repeat Password:</label>
                                                    <input type="password" class="form-control" id="rpass" placeholder="Repeat Password ">
                                                </div>
                                            </div>
                                            <div class="checkbox">
                                                <label class="form-label"><input class="form-check-input me-2" type="checkbox" value="" id="flexCheckChecked">Enable Two-Factor-Authentication</label>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Add New User</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Section Start -->
            <footer class="footer">
                <div class="footer-body">
                    <ul class="left-panel list-inline mb-0 p-0">
                        <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
                        <li class="list-inline-item"><a href="#">Terms of Use</a></li>
                    </ul>
                    <div class="right-panel">
                        ©<script>document.write(new Date().getFullYear())</script> BCW, Made with
                        <span class="text-gray">
                            <svg width="15" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M15.85 2.50065C16.481 2.50065 17.111 2.58965 17.71 2.79065C21.401 3.99065 22.731 8.04065 21.62 11.5806C20.99 13.3896 19.96 15.0406 18.611 16.3896C16.68 18.2596 14.561 19.9196 12.28 21.3496L12.03 21.5006L11.77 21.3396C9.48102 19.9196 7.35002 18.2596 5.40102 16.3796C4.06102 15.0306 3.03002 13.3896 2.39002 11.5806C1.26002 8.04065 2.59002 3.99065 6.32102 2.76965C6.61102 2.66965 6.91002 2.59965 7.21002 2.56065H7.33002C7.61102 2.51965 7.89002 2.50065 8.17002 2.50065H8.28002C8.91002 2.51965 9.52002 2.62965 10.111 2.83065H10.17C10.21 2.84965 10.24 2.87065 10.26 2.88965C10.481 2.96065 10.69 3.04065 10.89 3.15065L11.27 3.32065C11.3618 3.36962 11.4649 3.44445 11.554 3.50912C11.6104 3.55009 11.6612 3.58699 11.7 3.61065C11.7163 3.62028 11.7329 3.62996 11.7496 3.63972C11.8354 3.68977 11.9247 3.74191 12 3.79965C13.111 2.95065 14.46 2.49065 15.85 2.50065ZM18.51 9.70065C18.92 9.68965 19.27 9.36065 19.3 8.93965V8.82065C19.33 7.41965 18.481 6.15065 17.19 5.66065C16.78 5.51965 16.33 5.74065 16.18 6.16065C16.04 6.58065 16.26 7.04065 16.68 7.18965C17.321 7.42965 17.75 8.06065 17.75 8.75965V8.79065C17.731 9.01965 17.8 9.24065 17.94 9.41065C18.08 9.58065 18.29 9.67965 18.51 9.70065Z" fill="currentColor"></path>
                            </svg>
                        </span> by <a href="https://www.buywaw.com/">BCW Design</a>.
                    </div>
                </div>
            </footer>
            <!-- Footer Section End -->    </main>
        <!-- Wrapper End-->

        <!-- Library Bundle Script -->
        <script src="../jsfolder/libs.min.js"></script>

        <!-- External Library Bundle Script -->
        <script src="../jsfolder/external.min.js"></script>

        <!-- mapchart Script -->
        <script src="../jsfolder/vectore-chart.js"></script>
        <script src="../jsfolder/dashboard.js" defer></script>

        <!-- fslightbox Script -->
        <script src="../jsfolder/fslightbox.js"></script>

        <!-- AOS Animation Plugin-->

        <!-- App Script -->
        <script src="../jsfolder/vrooom.js" defer></script>
    </body>
</html>