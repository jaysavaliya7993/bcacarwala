<?php

use PHPMailer\PHPMailer\PHPMailer;

$r = mt_rand(100000, 999999);

$message = "Welcome to bcw";
//$no = $_GET['id'];

session_start();
include 'connection.php';

$email = $_POST['email'];
$password = $_POST['password'];
$_SESSION['u_email'] = $email;

$sql = "SELECT * FROM tbl_m_user WHERE u_email='$email' AND u_password='$password'";
$result = mysqli_query($conn, $sql);

if (!$row = mysqli_fetch_assoc($result)) {
    echo "<script language=\"JavaScript\">\n";
    echo "alert('Your Username or Password was incorrect!. Please try again.');\n";
//    echo "window.location='M_User.php'";
    echo "</script>";
} else {
    while ($row = mysqli_fetch_assoc($result)) {
        $_SESSION["u_email"] = $row['u_email'];
        // header("location:verify.php?id={$_SESSION["id"]}");
    }

    $sql = "UPDATE `onetimepassword` SET `mail`='$email',`otp`= $r";
    $result = mysqli_query($conn, $sql);

    require 'PHPMailer/vendor/autoload.php'; // library's file
    $mail = new PHPMailer(true); // PHPMailer obj
    $mail->isSMTP(); // method
    $mail->Host = 'smtp.gmail.com'; // host id
    $mail->Port = 465; // for sending msg
    $mail->SMTPSecure = 'ssl'; // for establish connection in gmail
    $mail->CharSet = 'utf-8'; // encoding form ma 
    $mail->SMTPAuth = true; // configure the established connection
    $mail->Username = 'bcacarwala185@gmail.com'; // admin's mail id for sending msg
    $mail->Password = 'hetiwlqarjytnllb'; // app password from google
    $mail->SetFrom('bcacarwala185@gmail.com', 'bcacarwala185'); // source 
    $mail->addAddress($email); // destination
    $mail->addReplyTo('bcacarwala185@gmail.com', 'bcacarwala185'); // for replying in mail
    $mail->SMTPDebug = false; // for finding error.
    $mail->IsHTML(true);
    $mailmessage = '
         <html>
         <head>
             <meta charset="utf-8">
             <meta name="description" content="Free Web tutorials" />
             <title>Mail</title>
             <meta name="keywords" content="HTML, CSS, JavaScript" />
             <meta name="viewport" content="width=device-width, initial-scale=1.0" />
             <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
         </head>
         
             <body style="width: 100%; font-family: \'Inter\', sans-serif; margin: 0; padding: 0; background-color: #ffffff;">
                <h2> YOUR ONE TIME PASSWORD IS </h2>
                <br>
                <br>
                <br>
                <h1> ' . $r . ' </h1>
             </body>
         </html>';

    $mail->Subject = 'Verify Your OneTimePassword';
    $mail->Body = $mailmessage;

    if ($mail->send()) {
        header("location:verify.php");
    } else {
        echo "<script language=\"JavaScript\">\n";
        echo "alert('Your login has been sucessfully.');\n";
        echo "window.location='../carfolder/Homepage.php";
        echo "</script>";
    }
}
?>

<?php

//use PHPMailer\PHPMailer\PHPMailer;
//
//session_start();
//$conn = mysqli_connect('localhost', 'root', '', 'bcw');
//
//if (!$conn) {
//    die("Connection failed");
//}
//
//$email = $_POST['email'];
//$password = $_POST['password'];
//$_SESSION['u_email'] = $email;
//
//$sql = "SELECT * FROM tbl_m_user WHERE u_email='$email' AND u_password='$password'";
//$result = mysqli_query($conn, $sql);
//
//if (!$row = mysqli_fetch_assoc($result)) {
//    echo "<script language=\"JavaScript\">\n";
//    echo "alert('Your Username or Password was incorrect!. Please try again.');\n";
//    echo "</script>";
//} else {
//    $r = mt_rand(100000, 999999);
//    $sql = "UPDATE `onetimepassword` SET `mail`='$email',`otp`= $r";
//    $result = mysqli_query($conn, $sql);
//
//    require 'PHPMailer/vendor/autoload.php';
//    $mail = new PHPMailer(true);
//    $mail->isSMTP();
//    $mail->Host = 'smtp.gmail.com';
//    $mail->Port = 465;
//    $mail->SMTPSecure = 'ssl';
//    $mail->CharSet = 'utf-8';
//    $mail->SMTPAuth = true;
//    $mail->Username = 'bcacarwala185@gmail.com';
//    $mail->Password = 'hetiwlqarjytnllb';
//    $mail->SetFrom('bcacarwala185@gmail.com', 'bcacarwala185');
//    $mail->addAddress($email);
//    $mail->addReplyTo('bcacarwala185@gmail.com', 'bcacarwala185');
//    $mail->SMTPDebug = false;
//    $mail->IsHTML(true);
//
//    $mailmessage = '
//         <html>
//         <head>
//             <meta charset="utf-8">
//             <meta name="description" content="Free Web tutorials" />
//             <title>Mail</title>
//             <meta name="keywords" content="HTML, CSS, JavaScript" />
//             <meta name="viewport" content="width=device-width, initial-scale=1.0" />
//             <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
//         </head>
//         <body style="width: 100%; font-family: \'Inter\', sans-serif; margin: 0; padding: 0; background-color: #ffffff;">
//            <h2>YOUR ONE TIME PASSWORD IS</h2>
//            <br>
//            <br>
//            <br>
//            <h1>' . $r . '</h1>
//         </body>
//         </html>';
//
//    $mail->Subject = 'Verify Your OneTimePassword';
//    $mail->Body = $mailmessage;
//
//    if ($result && $result->num_rows == 1) {
//        $row = $result->fetch_assoc();
//        $status = $row['status'];
//        if ($status == 1) {
//            $user_id = $row['u_id'];
////            header("Location: OTP_1.php?id=$user_id");
////            exit();
//        } else {
//            echo '<script>alert("Your account is not approved by the admin yet.");</script>';
//        }
//    }
//
//    if ($mail->send()) {
//        header("location: verify.php?u_id=$user_id");
//
////        exit();
//    } else {
//        echo "<script language=\"JavaScript\">\n";
//        echo "alert('Email sending failed.');\n";
//        echo "window.location='../carfolder/Homepage.php'";
//        echo "</script>";
//    }
//}
?>





