<?php
// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "bcw";

$email = $_POST['email'];
$password = $_POST['password'];

// Create connection
$conn = new mysqli('localhost', 'root', '', 'bcw');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// sql to delete a record
$sql = "select * from tbl_m_user where email = '$email'";
$sql = "update tbl_m_user set password = '$password' Where email = '$email'";

if ($conn->query($sql) === TRUE) {
//    echo "Record deleted successfully";
    echo "<script language=\"JavaScript\">\n";
    echo "alert('Record deleted successfully.');\n";
    echo "</script>";
} else {
    echo "<script language=\"JavaScript\">\n";
    echo "alert('Error deleting record: . $conn->error');\n";
    echo "</script>";
//    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>
<!-- "update m_user set password = '$password' Where email = '$email'"; -->
<!-- select eid,name,city,gender from emp where city="surat"; -->