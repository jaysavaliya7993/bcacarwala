
<?php

$username = $_POST['username'];
$phone_no = $_POST['phone_no'];
$email = $_POST['email'];
$password = $_POST['password'];

session_start();
$_SESSION['a_email'] = $email;

// database connect
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
     $email = $_POST['email'];

     // Validate email address
     if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
          // Check if email ends with "@email.com"
          if (substr($email, -10) == "@yahoo.com") 
          {
               //check password with 1 special ,1 numeric and 1 charecter in password
               if (preg_match('/^(?=.*[!@#$%^&*])(?=.*\d)(?=.*[a-z]).{8,}$/', $password)) 
               {
                    // Input is valid, do something here
                    // Email is valid, do something with it (send email, save to database, etc.)
                    $conn = new mysqli('localhost', 'root', '', 'bcw');
                    if ($conn->connect_error) 
                    {
                         die('Connection failed : ' . $conn->connect_error);
                    } 
                    else 
                    {
                         $sql = "insert into tbl_m_admin(a_username,a_phone_no,a_email,a_password) values ('$username','$phone_no','$email','$password')";
                         $sqlquiry = mysqli_query($conn, $sql);
                         echo "<script language=\"JavaScript\">\n";
                         echo "alert('$username Your Registration has been sucessfully.');\n";
                         echo "window.location='adashboard.php'";
                         echo "</script>";
                         $conn->close();
                    }
               } 
               else 
               {
                    // Email is not valid, display an error message
                    echo "<script language=\"JavaScript\">\n";
                    // echo "alert('$username Your Password has need min 8 charecter and max 20 length in Password and need 1 charecter and need 1 special charecter and need 1 number in password. please try again.');\n";
                    echo "window.location='M_Admin.php'";
                    echo "</script>";
               }
          }
          // Check if email ends with "@gmail.com"
          else if (substr($email, -10) == "@gmail.com") 
          {
               //check password with 1 special ,1 numeric and 1 charecter in password
               if (preg_match('/^(?=.*[!@#$%^&*])(?=.*\d)(?=.*[a-z]).{8,}$/', $password)) 
               {
                    // Input is valid, do something here
                    // Email is valid, do something with it (send email, save to database, etc.)
                    $conn = new mysqli('localhost','root','','bcw');
                    if ($conn->connect_error) 
                    {
                         die('Connection failed : ' . $conn->connect_error);
                    } 
                    else 
                    {
                         $sql = "insert into tbl_m_admin(a_username,a_phone_no,a_email,a_password) values('$username','$phone_no','$email','$password')";
                         $sqlquiry = mysqli_query($conn, $sql);
                         echo "<script language=\"JavaScript\">\n";
                         echo "alert('$username Your Registration has been sucessfully.');\n";
                         echo "window.location='adashboard.php'";
                         echo "</script>";
                         $conn->close();
                    }
               }
               else 
               {
                    // password is not valid, display an error message
                    echo "<script language=\"JavaScript\">\n";
                    echo "alert('$username unsuccessfull.');\n";
//                    echo "window.location='M_User.php'";
                    echo "</script>";
               }
          } 
          else 
          {
               // Email is not valid, display an error message
               echo "<script language=\"JavaScript\">\n";
               echo "alert('$username Your Email has been Invalid. Please Try Again.');\n";
//               echo "window.location='M_User.php'";
               echo "</script>";
          }
     } 
//     else 
//     {
//          // Email is not valid, display an error message
//          echo "<script language=\"JavaScript\">\n";
//          echo "alert('$username Your Email has been Invalid. Please Try Again.');\n";
//          echo "window.location='M_User.php'";
//          echo "</script>";
//     }
}

//$sql = "insert into tbl_m_admin(a_username,a_phone_no,a_email,a_password) values('$username','$phone_no','$email','$password')";
?>