<?php
session_start();
?>


<?php
 include 'connection.php';
//$conn = mysqli_connect('localhost', 'root', '', 'bcw');
//
//if (!$conn) {
//    die("Connection failed");
//}

if (isset($_POST['con'])) {

    $sql = "select * from onetimepassword";
    $result = mysqli_query($db, $sql);

    while ($row = mysqli_fetch_assoc($result)) {
        $otp = $row['otp'];

    }
    $ot = $_POST['1'] . $_POST['2'] . $_POST['3'] . $_POST['4'] . $_POST['5'] . $_POST['6'];
    if ($ot == $otp) {
        echo "<script>alert('OTP VERIFIRED')</script>";
        header("location:adashboard.php");

    } else {
        echo "<script>alert('PLEASE ENTER VALID OTP')</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!--<link rel="icon" href="./images/fj.png" type="image/gif" sizes="16x16">-->
    <title>BCACARWALA</title>

    <meta charset="utf-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">

    <link rel="stylesheet" href="css/animate.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="css/flaticon.css">

    <link rel="stylesheet" href="css/icomoon.css">

    <link rel="stylesheet" href="css/style.css">

    <style>
        body {
            background: #eee;
            background-image: url("https://www.bentleymotors.com/content/dam/bentley/Master/World%20of%20Bentley/Mulliner/redesign/coachbuilt/Mulliner%20Batur%201920x1080.jpg/_jcr_content/renditions/original.image_file.1920.1080.file/Mulliner%20Batur%201920x1080.jpg");
            /* background-position: center; */
            background-size: cover;
            /* overflow: hidden; */
        }

        .card {
            box-shadow: 0 20px 27px 0 rgb(0 0 0 / 5%);
        }

        .card {
            position: relative;
            display: flex;
            flex-direction: column;
            min-width: 0;
            word-wrap: break-word;
            background-color: #fff;
            background-clip: border-box;
            border: 0 solid rgba(0, 0, 0, .125);
            border-radius: 1rem;
        }

        /* .img-thumbnail {
            padding: .25rem;
            background-color: #ecf2f5;
            border: 1px solid #dee2e6;
            border-radius: .25rem;
            max-width: 100%;
            height: auto;
        } */

        /* .avatar-lg {
            height: 150px;
            width: 150px;
        } */
    </style>

</head>

<body>
    <div class="container">
        <br>
        <div class="row">
            <div class="col-lg-5 col-md-7 mx-auto my-auto">
                <div class="card">
                    <div class="card-body px-lg-5 py-lg-5 text-center">
                        <h2 class="text-info">TWO STEP VERIFICATION Security</h2>
                        <p class="mb-4">Enter 6-digits code from your BCA CAR WALA Login.</p>
                        <form action="" method="post">
                            <div class="row mb-4">
                                <div class="col-lg-2 col-md-2 col-2 ps-0 ps-md-2">
                                    <input type="text" class="form-control text-lg text-center" placeholder="_" name="1"
                                        minlength="1" maxlength="1" required oninput="moveNext(this, otp2)" onkeydown="moveBack(this, otp1, event)">
                                </div>
                                <div class="col-lg-2 col-md-2 col-2 ps-0 ps-md-2">
                                    <input type="text" class="form-control text-lg text-center" placeholder="_" name="2"
                                        minlength="1" maxlength="1" oninput="moveNext(this, otp3)" onkeydown="moveBack(this, otp2, event)">
                                </div>
                                <div class="col-lg-2 col-md-2 col-2 ps-0 ps-md-2">
                                    <input type="text" class="form-control text-lg text-center" placeholder="_" name="3"
                                        minlength="1" maxlength="1" oninput="moveNext(this, otp4)" onkeydown="moveBack(this, otp3, event)">
                                </div>
                                <div class="col-lg-2 col-md-2 col-2 pe-0 pe-md-2">
                                    <input type="text" class="form-control text-lg text-center" placeholder="_" name="4"
                                        minlength="1" maxlength="1" oninput="moveNext(this, otp5)" onkeydown="moveBack(this, otp4, event)">
                                </div>
                                <div class="col-lg-2 col-md-2 col-2 pe-0 pe-md-2">
                                    <input type="text" class="form-control text-lg text-center" placeholder="_" name="5"
                                        minlength="1" maxlength="1" oninput="moveNext(this, otp6)" onkeydown="moveBack(this, otp5, event)">
                                </div>
                                <div class="col-lg-2 col-md-2 col-2 pe-0 pe-md-2">
                                    <input type="text" class="form-control text-lg text-center" placeholder="_" name="6"
                                        minlength="1" maxlength="1" onkeydown="moveBack(this, otp5, event)">
                                </div>
                            </div>
                            <div class="text-center">
                                <input type="submit" name="con" class="btn bg-info btn-lg my-4">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



</body>

</html>