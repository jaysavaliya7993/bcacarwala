<?php
session_start();
?>

<html>

<head>
    <meta charset="UTF-8">
    <title>Admin Login Registration page</title>
    <!-- connet to css -->
    <link rel="stylesheet" href="../cssfolder/admin.css">
    <link rel="stylesheet" href="../cssfolder/new.css">

    <style>
        .input-group {
            position: relative;
            width: 100%;
            margin: .5rem 0;
            /* margin: .5rem .1rem; */
        }
    </style>
</head>

<body>

    <div id="container" class="container">
        <!-- FORM SECTION -->

        <div class="row">
            <!-- REGISTRATION -->
            <div class="col align-items-center flex-col sign-up">
                <div class="form-wrapper align-items-center">
                    <div class="form sign-up">

                        <form action="Back_hand.php" method="POST">

                            <div class="input-group">
                                <!--<i class='bx bxs-user'></i>-->
                                <input type="text" name="username" onkeypress="return /[a-z A-Z ]/i.test(event.key)"
                                    placeholder="Username" title="Username must have alphabet">
                            </div>

                            <div class="input-group">
                                <!--<i class='bx bx-mail-send'></i>-->
                                <input type="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$"
                                    placeholder="Email" required>
                            </div>

                            <div class="input-group">
                                <!--<i class='bx bxs-lock-alt'></i>-->
                                <input type="tel" name="phone_no" placeholder="Phone no"
                                    onkeypress="return /[0-9]/i.test(event.key)" pattern="[0-9]{10}">
                            </div>

                            <div class="input-group">
                                <!--<i class='bx bxs-lock-alt'></i>-->
                                <input type="password" name="password" id="psw" placeholder="Password"
                                    pattern="(?=.*\d)(?=.*[a-z]).{8,}" title="Must contain at least one number and and lowercase letter, 
                                and at least 8 or more characters" required>
                            </div>

                            <!-- password validation  -->
                            <!-- <div id="mess">
                                <h3>Password must contain the following:</h3>
                                <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
                                <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
                                <p id="number" class="invalid">A <b>number</b></p>
                                <p id="length" class="invalid">Minimum <b>8 characters</b></p>
                            </div> -->

                            <!-- <div class="input-group">
                                    <i class='bx bxs-lock-alt'></i>
                                    <input type="password" placeholder="Confirm password">
                                </div> -->

                            <button>Register</button>

                        </form>

                        <p><span>Already have an account?</span>
                            <b onclick="toggle()" class="pointer">Log in here</b>
                        </p>
                    </div>
                </div>
            </div>
            <!-- END REGISTRATION -->
            <!-- LOG IN -->
            <div class="col align-items-center flex-col sign-in">
                <div class="form-wrapper align-items-center">
                    <div class="form sign-in">

                        <form action="Facth_data.php" method="POST">

                            <div class="input-group">
                                <!--<i class='bx bxs-user'></i>-->
                                <input type="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$"
                                    placeholder="Email" required>
                            </div>

                            <div class="input-group">
                                <!--<i class='bx bxs-lock-alt'></i>-->
                                <input type="password" name="password" id="psw" placeholder="Password"
                                    pattern="(?=.*\d)(?=.*[a-z]).{8,}" title="Must contain at least one number and and lowercase letter, 
                                and at least 8 or more characters" required>
                            </div>

                            <!-- password validation  -->
                            <!-- <div id="mess">
                                <h3>Password must contain the following:</h3>
                                <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
                                <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
                                <p id="number" class="invalid">A <b>number</b></p>
                                <p id="length" class="invalid">Minimum <b>8 characters</b></p>
                            </div> -->

                            <button>Log in</button>

                        </form>

                        <p><b><a href="forgot.php">Forgot password?</a></b></p>

                        <p><span>Don't have an account?</span>
                            <b onclick="toggle()" class="pointer">Register here</b>
                        </p>
                    </div>
                </div>
                <div class="form-wrapper">

                </div>
            </div>
            <!-- END LOG IN -->
            </form>
        </div>
        <!-- END FORM SECTION -->

        <!-- CONTENT SECTION -->
        <div class="row content-row">
            <!-- SIGN IN CONTENT -->
            <div class="col align-items-center flex-col">
                <div class="text sign-in">
                    <h2>Welcome To BcaCarWala</h2>
                </div>
                <div class="img sign-in"></div>
            </div>
            <!-- END SIGN IN CONTENT -->
            <!-- SIGN UP CONTENT -->
            <div class="col align-items-center flex-col">
                <div class="img sign-up"></div>

                <div class="text sign-up">
                    <h2>Thank You For Join With Us</h2>
                </div>

            </div>
            <!-- END SIGN UP CONTENT -->
        </div>
        <!-- END CONTENT SECTION -->
    </div>

    <script>
        let container = document.getElementById('container')

        toggle = () => {
            container.classList.toggle('sign-in')
            container.classList.toggle('sign-up')
        }

        setTimeout(() => {
            container.classList.add('sign-in')
        }, 200)
    </script>

    <!--show password--><!-- password validation -->
    <script>
        var myInput = document.getElementById("psw");
        var letter = document.getElementById("letter");
//        var capital = document.getElementById("capital");
        var number = document.getElementById("number");
        var length = document.getElementById("length");

        // When the user clicks on the password field, show the message box
        myInput.onfocus = function () {
            document.getElementById("mess").style.display = "block";
        }

        // When the user clicks outside of the password field, hide the message box
        myInput.onblur = function () {
            document.getElementById("mess").style.display = "none";
        }

        // When the user starts to type something inside the password field
        myInput.onkeyup = function () {
            // Validate lowercase letters
            var lowerCaseLetters = /[a-z]/g;
            if (myInput.value.match(lowerCaseLetters)) {
                letter.classList.remove("invalid");
                letter.classList.add("valid");
            }
            else {
                letter.classList.remove("valid");
                letter.classList.add("invalid");
            }

            // Validate capital letters
//            var upperCaseLetters = /[A-Z]/g;
//            if (myInput.value.match(upperCaseLetters)) {
//                capital.classList.remove("invalid");
//                capital.classList.add("valid");
//            }
//            else {
//                capital.classList.remove("valid");
//                capital.classList.add("invalid");
//            }

            // Validate numbers
            var numbers = /[0-9]/g;
            if (myInput.value.match(numbers)) {
                number.classList.remove("invalid");
                number.classList.add("valid");
            }
            else {
                number.classList.remove("valid");
                number.classList.add("invalid");
            }

            // Validate length
            if (myInput.value.length >= 8) {
                length.classList.remove("invalid");
                length.classList.add("valid");
            }
            else {
                length.classList.remove("valid");
                length.classList.add("invalid");
            }
        }
    </script>

</body>

</html>